package taskManager1;

public class Task {
    String name;
    String dueDate;
    boolean isUrgent;
    String category;
    boolean isCompleted;
    Task next;

    Task(String name, String dueDate, boolean isUrgent, String category) {
        this.name = name;
        this.dueDate = dueDate;
        this.isUrgent = isUrgent;
        this.category = category;
        this.isCompleted = false;
        this.next = null;
    }

    @Override
    public String toString() {
        return "Task Name: " + name + "\nDue Date: " + dueDate + "\nIs Urgent: " + isUrgent + "\nCategory: " + category + "\nIs Completed: " + isCompleted;
    }
}
