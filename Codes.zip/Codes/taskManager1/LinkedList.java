package taskManager1;

public class LinkedList {
	private Node head;
    private Node tail;

    public boolean isEmpty() {
        return head == null;
    }
    public void addLast(Task task) {
        Node newNode = new Node(task);
        if (isEmpty()) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
    }
    public void removeFirst() {
        if (isEmpty()) {
            System.out.println("List is empty");
        } else {
            head = head.next;
            if (head == null) {
                tail = null;
            }
        }
    }
    public Node getHead() {
        return head;
    }

    public void printLL() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }
    public static class Node {
        Task task;
        Node next;

        Node(Task task) {
            this.task = task;
            this.next = null;
        }
    }
}
