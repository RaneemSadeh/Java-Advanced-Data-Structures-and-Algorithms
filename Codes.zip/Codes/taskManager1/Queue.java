package taskManager1;

public class Queue {
	private LinkedList queueList;

    public Queue() {
        queueList = new LinkedList();
        Task task;
    }

    public void enqueue(Task task) {
        queueList.addLast(task);
    }

    public void dequeue() {
        queueList.removeFirst();
    }

    public Task getFront() {
        if (!isEmpty()) {
            return queueList.getHead().task;
        }
        return null;
    }

    public boolean isEmpty() {
        return queueList.isEmpty();
    }

    public void printQueue() {
        queueList.printLL();
    }
}
