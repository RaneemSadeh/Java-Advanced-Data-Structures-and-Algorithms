package taskManager1;

public class Category {
    private CategoryNode head;

    private static class CategoryNode {
        String category;
        Task taskHead;
        CategoryNode next;

        CategoryNode(String category) {
            this.category = category;
            this.taskHead = null;
            this.next = null;
        }
    }

    private static class Task {
        String taskName;
        Task next;

        Task(String taskName) {
            this.taskName = taskName;
            this.next = null;
        }
    }
    public Category() {
        this.head = null;
    }

    public void addCategoriestask(String category, String taskName) {//I'm going to add the category of the task.
        CategoryNode current = head; 
        CategoryNode prev = null;
        while (current != null) {
            if (current.category.equals(category)) {
                addTaskToCategoryNode(current, taskName);
                return;
            }
            prev = current;
            current = current.next;
        }
        CategoryNode newCategoryNode = new CategoryNode(category);
        addTaskToCategoryNode(newCategoryNode, taskName);
        if (prev != null) {
            prev.next = newCategoryNode;
        } else {
            head = newCategoryNode;
        }
    }

    private void addTaskToCategoryNode(CategoryNode categoryNode, String taskName) { //Adding it to the node
        Task newTaskNode = new Task(taskName);
        if (categoryNode.taskHead == null) {
            categoryNode.taskHead = newTaskNode;
        } else {
            Task current = categoryNode.taskHead;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newTaskNode;
        }
    }

    public void displaytasksbytheirCategory() { //Printing the taskss category
        if (head == null) {
            System.out.println("There is ni any task and category to show for you :(");
            return;
        }
        CategoryNode current = head;
        while (current != null) {
            System.out.println(current.category + ":");
            Task taskCurrent = current.taskHead;
            while (taskCurrent != null) {
                System.out.println("<-->" + taskCurrent.taskName);
                taskCurrent = taskCurrent.next;
            }
            current = current.next;
        }
    }
}
