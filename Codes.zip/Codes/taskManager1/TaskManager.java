package taskManager1;

public class TaskManager {
    private Task head;
    private int size;
    private Queue completedTasksQueue;
    private IsUrgentStack urgentTaskStack;
    private Category categoryManager;

    public TaskManager() {
        head = null;
        size = 0;
        this.completedTasksQueue = new Queue();
        this.urgentTaskStack = new IsUrgentStack();
        this.categoryManager = new Category();
    }

    public void addTask(String name, String dueDate, char isUrgent, String category) {
        if (!dueDate.matches("\\d{4}/\\d{2}/\\d{2}")) {
            System.out.println("This format is wrong, Please use YYYY/MM/DD.");
            return;
        }

        boolean urgentFlag = (isUrgent == 't');
        Task newTask = new Task(name, dueDate, urgentFlag, category);

        if (head == null) {
            head = newTask;
        } else {
            Task current = head;
            Task previous = null;
            while (current != null && compareDueDates(current.dueDate, newTask.dueDate) < 0) {
                previous = current;
                current = current.next;
            }
            if (previous == null) {
                newTask.next = head;
                head = newTask;
            } else {
                previous.next = newTask;
                newTask.next = current;
            }
        }

        if (newTask.isUrgent) {
            urgentTaskStack.push(newTask);
        }
        categoryManager.addCategoriestask(category.toLowerCase(), name);
        size++;
    }

    private int compareDueDates(String date1, String date2) {
        return date1.compareTo(date2);
    }

    public void markTaskCompleted(String taskName) {
        if (size == 0) {
            System.out.println("There are no tasks to mark completed.");
            return;
        }
        Task current = head;
        Task previous = null;
        while (current != null) {
            if (current.name.equals(taskName)) {
                current.isCompleted = true;
                if (previous != null) {
                    previous.next = current.next;
                } else {
                    head = current.next;
                }
                completedTasksQueue.enqueue(current);
                size--;
                return;
            }
            previous = current;
            current = current.next;
        }
        System.out.println("Task not found.");
    }

    public void displayTasksByDueDate() {
        if (size == 0) {
            System.out.println("There are no tasks to display.");
            return;
        }
        Task current = head;
        while (current != null) {
            System.out.println(current);
            System.out.println();
            current = current.next;
        }
    }

    public void viewCompletedTasksHistory() {
        if (completedTasksQueue.isEmpty()) {
            System.out.println("There are no completed tasks to view.");
            return;
        }
        completedTasksQueue.printQueue();
    }

    public void retrieveUrgentTasks() {
        if (urgentTaskStack.isEmpty()) {
            System.out.println("There are no urgent tasks to retrieve.");
            return;
        }
        IsUrgentStack tempStack = new IsUrgentStack();
        while (!urgentTaskStack.isEmpty()) {
            Task task = urgentTaskStack.pop();
            System.out.println(task);
            tempStack.push(task);
        }
        while (!tempStack.isEmpty()) {
            urgentTaskStack.push(tempStack.pop());
        }
    }

    public void sortTasksByCategory() {
        categoryManager.displaytasksbytheirCategory();
    }
}
