package taskManager1;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        TaskManager taskman = new TaskManager();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nRaneem's Task Management System");
            System.out.println("--------------------------------");
            System.out.println("1. Add Task");
            System.out.println("2. Mark Task Completed");
            System.out.println("3. Display Tasks By Due Date");
            System.out.println("4. View Completed Tasks History");
            System.out.println("5. Retrieve Urgent Tasks");
            System.out.println("6. Sort Tasks By Category");
            System.out.println("7. Ending");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter task name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter due date (YYYY/MM/DD): ");
                    String dueDate = scanner.nextLine();
                    System.out.print("Is it urgent? (t/f): ");
                    char isUrgent = scanner.nextLine().charAt(0);
                    System.out.print("Enter category: ");
                    String category = scanner.nextLine();
                    taskman.addTask(name, dueDate, isUrgent, category);
                    break;
                case 2:
                    System.out.print("Enter the task name that you want to mark as completed: ");
                    String taskName = scanner.nextLine();
                    taskman.markTaskCompleted(taskName);
                    break;
                case 3:
                    taskman.displayTasksByDueDate();
                    break;
                case 4:
                    taskman.viewCompletedTasksHistory();
                    break;
                case 5:
                    taskman.retrieveUrgentTasks();
                    break;
                case 6:
                    taskman.sortTasksByCategory();
                    break;
                case 7:
                    System.out.println("Ending... thank you for using Raneem's Task Management <3 See you again!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 7);

        scanner.close();
   
}
}