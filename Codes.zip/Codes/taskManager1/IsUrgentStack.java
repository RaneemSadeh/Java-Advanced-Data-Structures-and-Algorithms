package taskManager1;

public class IsUrgentStack {
	private Node head;

    private static class Node {
        Task task;
        Node next;

        public Node(Task task) {
            this.task = task;
            this.next = null;
        }
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void push(Task task) {
        if (task.isUrgent) {
            Node newNode = new Node(task);
            newNode.next = head;
            head = newNode;
        }
    }

    public Task pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");
            return null;
        }
        Node temp = head;
        head = head.next;
        return temp.task;
    }

    public Task peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");
            return null;
        }
        return head.task;
    }
}
