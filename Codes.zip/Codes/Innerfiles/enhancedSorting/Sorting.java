package enhancedSorting;

import java.util.Random;

public class Sorting {

    public static void main(String[] args) {
        int[] sizes = {100000, 1000000}; //the two sizes of the array
        String[] arrayTypes = {"sorted", "random", "reversely sorted"}; // The types that I am going to use in the array

        for (int size : sizes) {
            for (String type : arrayTypes) {
                int[] array = generatingtheArray(size, type);

                // the time for the merge sort
                long startTime = System.nanoTime();
                mergeSort(array.clone());
                long endTime = System.nanoTime();
                System.out.println("Merge Sort - Size: " + size + ", Type: " + type + ", Time: " + (endTime - startTime) / 1000000.0 + " ms");

                // And here is the time for the enhanced sort
                startTime = System.nanoTime();
                enhancedSelectionSort(array.clone());
                endTime = System.nanoTime();
                System.out.println("Enhanced Selection Sort - Size: " + size + ", Type: " + type + ", Time: " + (endTime - startTime) / 1000000.0 + " ms");
            }
        }
    }

    private static int[] generatingtheArray(int size, String type) {
        int[] array = new int[size];
        Random rand = new Random();

        switch (type) {
            case "sorted":
                for (int i = 0; i < size; i++) {
                    array[i] = i;
                }
                break;
            case "random":
                for (int i = 0; i < size; i++) {
                    array[i] = rand.nextInt(size);
                }
                break;
            case "reversely sorted":
                for (int i = 0; i < size; i++) {
                    array[i] = size - i;
                }
                break;
        }

        return array;
    }

    private static void mergeSort(int[] inputArray) {
        int inputLength = inputArray.length;

        if (inputLength < 2) {
            return;
        }

        int midIndex = inputLength / 2;
        int[] leftHalf = new int[midIndex];
        int[] rightHalf = new int[inputLength - midIndex];

        for (int i = 0; i < midIndex; i++) {
            leftHalf[i] = inputArray[i];
        }

        for (int i = midIndex; i < inputLength; i++) {
            rightHalf[i - midIndex] = inputArray[i];
        }

        mergeSort(leftHalf);
        mergeSort(rightHalf);

        merge(inputArray, leftHalf, rightHalf);
    }

    private static void merge(int[] inputArray, int[] leftHalf, int[] rightHalf) {
        int leftSize = leftHalf.length;
        int rightSize = rightHalf.length;

        int i = 0, j = 0, k = 0;

        while (i < leftSize && j < rightSize) {
            if (leftHalf[i] <= rightHalf[j]) {
                inputArray[k] = leftHalf[i];
                i++;
            } else {
                inputArray[k] = rightHalf[j];
                j++;
            }
            k++;
        }

        while (i < leftSize) {
            inputArray[k] = leftHalf[i];
            i++;
            k++;
        }

        while (j < rightSize) {
            inputArray[k] = rightHalf[j];
            j++;
            k++;
        }
    }

    private static void enhancedSelectionSort(int[] arr) {
        int n = arr.length;

        for (int i = 0; i < n / 2; i++) {
            int minIdx = i;
            int maxIdx = i;
            for (int j = i + 1; j < n - i; j++) {
                if (arr[j] < arr[minIdx]) {
                    minIdx = j;
                }
                if (arr[j] > arr[maxIdx]) {
                    maxIdx = j;
                }
            }

            // Here I'm going to make swap min element with first element
            int temp = arr[minIdx];
            arr[minIdx] = arr[i];
            arr[i] = temp;

            // Here I going to confirm the change of the position of the max element if it was moved
            if (maxIdx == i) {
                maxIdx = minIdx;
            }

            // Here I'm going to make swap max element with last element
            temp = arr[maxIdx];
            arr[maxIdx] = arr[n - 1 - i];
            arr[n - 1 - i] = temp;
        }
    }
 }