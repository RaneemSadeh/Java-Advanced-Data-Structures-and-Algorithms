package dijkstraBellman;

public class Graph {
    int vertices;
    int[][] adjacencyMatrix;

    public Graph(int vertices) {
        this.vertices = vertices;
        adjacencyMatrix = new int[vertices][vertices];
        for (int i = 0; i < vertices; i++) {
            for (int j = 0; j < vertices; j++) {
                adjacencyMatrix[i][j] = Integer.MAX_VALUE; 
            }
        }
    }

    public void addEdge(int src, int dest, int weight) {
        adjacencyMatrix[src][dest] = weight;
    }


    public void printGraph() {
        System.out.print("\t");
        for (int i = 0; i < vertices; i++) {
            System.out.print((char) ('A' + i) + "\t");
        }
        System.out.println();
        for (int i = 0; i < vertices; i++) {
            System.out.print((char) ('A' + i) + "\t");
            for (int j = 0; j < vertices; j++) {
                if (adjacencyMatrix[i][j] == Integer.MAX_VALUE) {
                    System.out.print("∞\t");
                } else {
                    System.out.print(adjacencyMatrix[i][j] + "\t");
                }
            }
            System.out.println();
        }
    }
}