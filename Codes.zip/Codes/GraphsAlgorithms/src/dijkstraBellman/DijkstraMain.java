package dijkstraBellman;

public class DijkstraMain {
    public static void main(String[] args) {
        int V = 9; // Number of vertices
        Graph graph = new Graph(V);

        graph.addEdge(0, 1, 1);
        graph.addEdge(0, 5, 1);
        graph.addEdge(0, 2, 1);
        graph.addEdge(1, 0, 1);
        graph.addEdge(1, 2, 2);
        graph.addEdge(2, 3, 8);
        graph.addEdge(3, 4, 9);
        graph.addEdge(3, 8, 1);
        graph.addEdge(5, 6, 3);
        graph.addEdge(5, 2, 5);
        graph.addEdge(6, 7, 6);
        graph.addEdge(6, 4, 6);
        graph.addEdge(6, 2, 2);
        graph.addEdge(7, 8, 7);
        graph.addEdge(7, 3, 2);
        graph.addEdge(4, 8, 4);
        System.out.println("-------------------------");
        System.out.println("Dijkstra's Algorithm:");
        System.out.println("-------------------------");
        graph.printGraph();
        System.out.println("-------------------------------------------------");
        System.out.println("Dijkstra's Algorithm:");
        int[] dijkstraResult = Dijkstra.shortestPath(graph, 0);
        for (int i = 0; i < V; i++) {
            System.out.println("Distance from Task A to " + (char) ('A' + i) + ": " + dijkstraResult[i]);
        }
        System.out.println("-------------------------");
        System.out.println("--- BellMan Algorithm ---");
        System.out.println("-------------------------");
        Bellman.shortestPath(graph, 0);
    }
}