package dijkstraBellman;

public class Bellman {
    public static void shortestPath(Graph graph, int start) {
        int V = graph.vertices;
        int[] distances = new int[V];
        int[] parents = new int[V];

        for (int i = 0; i < V; i++) {
            distances[i] = Integer.MAX_VALUE;
            parents[i] = -1;
        }
        distances[start] = 0;

        for (int i = 1; i < V; i++) {
            for (int u = 0; u < V; u++) {
                for (int v = 0; v < V; v++) {
                    if (graph.adjacencyMatrix[u][v] != Integer.MAX_VALUE && distances[u] != Integer.MAX_VALUE &&
                        distances[u] + graph.adjacencyMatrix[u][v] < distances[v]) {
                        distances[v] = distances[u] + graph.adjacencyMatrix[u][v];
                        parents[v] = u;
                    }
                }
            }
        }

        for (int u = 0; u < V; u++) {
            for (int v = 0; v < V; v++) {
                if (graph.adjacencyMatrix[u][v] != Integer.MAX_VALUE && distances[u] != Integer.MAX_VALUE &&
                    distances[u] + graph.adjacencyMatrix[u][v] < distances[v]) {
                    System.out.println("Graph contains a negative-weight cycle");
                    return;
                }
            }
        }
        printSolution(distances, parents, start);
    }
    
    private static void printSolution(int[] distances, int[] parents, int start) {
        System.out.println("Node\tDistance\tParent");
        for (int i = 0; i < distances.length; i++) {
            char parentChar = (parents[i] == -1) ? '-' : (char) ('A' + parents[i]);
            System.out.println((char) ('A' + i) + "\t" + distances[i] + "\t\t" + parentChar);
        }
    }
}