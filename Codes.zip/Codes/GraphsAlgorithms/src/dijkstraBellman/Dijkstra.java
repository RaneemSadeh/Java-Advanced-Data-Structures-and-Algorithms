package dijkstraBellman;

//the Dijkstra Algorithm

public class Dijkstra {
	    public static int[] shortestPath(Graph graph, int start) {
	        int V = graph.vertices;
	        int[] distances = new int[V];
	        boolean[] visited = new boolean[V];

	        for (int i = 0; i < V; i++) {
	            distances[i] = Integer.MAX_VALUE;
	            visited[i] = false;
	        }

	        distances[start] = 0;

	        for (int count = 0; count < V - 1; count++) {
	            int u = minDistance(distances, visited, V);
	            visited[u] = true;

	            for (int v = 0; v < V; v++) {
	                if (!visited[v] && graph.adjacencyMatrix[u][v] != Integer.MAX_VALUE &&
	                    distances[u] != Integer.MAX_VALUE && distances[u] + graph.adjacencyMatrix[u][v] < distances[v]) {
	                    distances[v] = distances[u] + graph.adjacencyMatrix[u][v];
	                }
	            }
	        }
	        return distances;
	    }

	    private static int minDistance(int[] distances, boolean[] visited, int V) {
	        int min = Integer.MAX_VALUE, minIndex = -1;

	        for (int v = 0; v < V; v++) {
	            if (!visited[v] && distances[v] <= min) {
	                min = distances[v];
	                minIndex = v;
	            }
	        }
	        return minIndex;
	    }
	}